// /* global swd:true */
// (function(window) {
//   "use strict";

//   // window.injected_main = function() {
//   //   var frame = document.createElement("iframe");
//   //   frame.classList.add('swd-iframe');
//   //   frame.classList.add('swd-none');
//   //   document.body.appendChild(frame);
//   //   frame.contentType = "text/html";
//   //   frame.src = "https://stop-web-disability.org";
//   // };
// })(window);

