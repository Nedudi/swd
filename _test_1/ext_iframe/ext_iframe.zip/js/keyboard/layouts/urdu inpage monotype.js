﻿VirtualKeyboard.addLayout({code:'UR-PK'
,name:'Urdu Inpage Monotype'
,normal:'ٗضصظطًٰٓذدڈںؒ۔پٹشستنھجچحخ،قفیبلامکغعےژڑثءگزروہۃ'
,shift:{0:'؛()[]',6:'-',8:'‘’؟ﷺؓ؎آأ',17:'ئؤيٌ',25:':ٍُِّؑ\u0601َْؐؔ',37:'۰۹۸۷۶۵۴۳۲۱'}});