﻿VirtualKeyboard.addLayout({code:'KA-GE'
,name:'Georgian'
,normal:'„!?№§%:.;,/–=(ღჯუკენგშწზხცფძვთაპროლდჟჭჩყსმიტქბჰ'
,shift:{0:'“1234567890-+)'}
,alt:{18:'ჱ',24:'ჴ',26:'ჶ',28:'ჳ',42:'ჲ',46:'ჵ'}});