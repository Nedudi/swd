﻿VirtualKeyboard.addLayout({code:'ES'
,name:'Spanish Variation'
,normal:'\'1234567890-¨´qwertyuiop÷`asdfghjklñçzxcvbnm,.='
,shift:{0:'·ª"/()¡!¿?₧+¨´',24:'×`',44:';:%'}
,alt:{0:'\\|@#¼½¬_#§\\*~}',16:'€',24:'[]$&@[]|£±',35:'~{',45:'^'}
,caps:{24:'×'}
,shift_caps:{24:'÷'}
,dk:{'¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','~':'nñaãoõNÑAÃOÕ ~','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','´':'aáeéuúiíyýoóAÁEÉUÚIÍOÓ ´','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});