﻿VirtualKeyboard.addLayout({code:'RU'
,name:'Russian Translit'
,normal:'ё1234567890-ъэяшертыуиопющасдфгчйкльжзхцвбнм;.='
,shift:{1:'№!/":«»?()_',44:'\',%'}});