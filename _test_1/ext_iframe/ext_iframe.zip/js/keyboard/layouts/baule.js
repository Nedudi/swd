﻿VirtualKeyboard.addLayout({code:'BCI-CI'
,name:'Baule'
,normal:'`1234567890-=\\qwertyuiopɛɔasdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#₵%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',8:'̣̆',24:'[]',36:'́'}
,shift_alt:{0:'̃',24:'{}',36:'̈'}
,dk:{'\\':'ɛqƐQɔxƆX`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});