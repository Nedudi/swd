﻿VirtualKeyboard.addLayout({code:'KU'
,name:'Kurdish Cyrillic'
,normal:'\'1234567890әъэqwертöуиопшщасдфгhйкльжзхчвбнм,.;'
,shift:{0:'"!@#$%^&*()',44:'<>:'}
,caps:{0:'"'}
,shift_caps:{0:'\''}});