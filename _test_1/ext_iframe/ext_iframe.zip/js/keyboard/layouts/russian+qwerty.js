﻿VirtualKeyboard.addLayout({code:'RU'
,name:'Russian_Qwerty'
,normal:'ё1234567890-=\\йцукенгшщзхъфывапролджэячсмитьбю.'
,shift:{1:'!"№;%:?*()_+/',46:','}
,alt:{0:'`',14:'QWERTYUIOP[]ASDFGHJKL;\'ZXCVBNM,.'}});