﻿VirtualKeyboard.addLayout({code:'CE'
,name:'Chechen Latin'
,normal:'äċçç̇ġẋq̇öņşü-ƶƖƿqwErtyuiopǝƖėasDfghjkl;\'zxCvbnm,./'
,shift:{8:'ŋ',11:'_',13:'UO',24:'ƏIE',35:':"',44:'<>?'}
,caps:{24:'Ə'}
,shift_caps:{24:'ǝ'}});