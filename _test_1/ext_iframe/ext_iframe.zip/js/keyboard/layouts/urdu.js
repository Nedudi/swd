﻿VirtualKeyboard.addLayout({code:'UR-PK'
,name:'Urdu'
,normal:'`1234567890-=\\طصھدٹپتبجح][مورنلہاکی؛\'قفےسشغع،۔/'
,shift:{0:'~!@#$٪^ۖ٭)(_+|ظضذڈثّۃـچخ}{ژزڑںۂءآگي:"\u200d\u200cۓ\u200eؤئ\u200f><؟'}});