﻿VirtualKeyboard.addLayout({code:'MNK-GN'
,name:'Mande'
,normal:'`1234567890-=\\ɛwertyuiopƝ]asdfghƒkl;\'zɔcŋbnm,./'
,shift:{0:'~!@#₦%^&*()_+|',25:'}',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',14:'q',16:'ê',22:'ô',24:'[',30:'ɣ',32:'j',36:'́',38:'x',40:'v',45:'̣'}
,shift_alt:{24:'{'}
,dk:{'\\':'ɛqƐQɔxƆXŋvŊV'}});