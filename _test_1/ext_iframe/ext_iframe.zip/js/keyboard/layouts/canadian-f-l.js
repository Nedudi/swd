﻿VirtualKeyboard.addLayout({code:'FR-CA'
,name:'Canadian French (Legacy)'
,normal:'°1234567890-=àqwertyuiop^çasdfghjkl;èzxcvbnm,.é'
,shift:{1:'!"#$%?&*()_+',24:'^',35:':',44:'\''}
,alt:{0:'¬¹@³¼½¾{[]}|¸`',17:'¶',19:'¥',22:'øþ°~æßðª',35:'´',37:'«»¢',43:'µ<>/'}
,shift_alt:{1:'¡²£¤',9:'±',11:'¿',13:'`',17:'®',25:'¨',27:'§',35:'´',39:'©',43:'º'}
,dk:{'¸':'cçCÇ','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','~':'nñaãoõNÑAÃOÕ ~','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});