﻿VirtualKeyboard.addLayout({code:'MI-NZ'
,name:'Maori'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,dk:{'`':'aāeēuūiīoō``AĀEĒUŪIĪOŌ ~'}});