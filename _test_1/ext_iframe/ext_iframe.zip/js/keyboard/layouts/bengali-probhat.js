﻿VirtualKeyboard.addLayout({code:'BN-IN'
,name:'Probhat Phonetic'
,normal:'\u200d১২৩৪৫৬৭৮৯০-=\u200cদূীরটএুিওপেোাসডতগহজকল;\'য়শচআবনম,।্'
,shift:{0:'~!@#৳%^ঞৎ()_+॥ধঊঈড়ঠঐউইঔফৈৌঅষঢথঘঃঝখং:"যঢ়ছঋভণঙৃঁ?'}});