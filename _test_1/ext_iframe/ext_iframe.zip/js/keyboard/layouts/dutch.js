﻿VirtualKeyboard.addLayout({code:'NL'
,name:'Dutch'
,normal:'@1234567890/°<qwertyuiop¨*asdfghjkl+´zxcvbnm,.-'
,shift:{0:'§!"#$%&_()\'?~>',24:'^|',35:'±`',44:';:='}
,alt:{0:'¬¹²³¼½¾£{}',11:'\\¸',16:'€¶',27:'ß',37:'«»¢',43:'µ',45:'·'}
,dk:{'~':'nñaãoõNÑAÃOÕ ~','¸':'cçCÇ ¸','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});