﻿VirtualKeyboard.addLayout({code:'LT'
,name:'Lithuanian extended'
,normal:'`!-/;:,.=()?xqąžertyuiopįwasdšghjklųėzūcvbnmčfę'
,shift:{0:'~1234567890+'}
,alt:{0:'´@_#$§^&*[]\'%|',16:'€',24:'{}',36:'"',44:'„“\\'}});