﻿VirtualKeyboard.addLayout({code:'BAM-ML'
,name:'Bambara'
,normal:'`1234567890-=\\qwertyuiopɛɔasdfghjkl;\'zɲcŋbnm,./'
,shift:{0:'~!@#₦%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',8:'̣̆',24:'[]',36:'́',38:'x',40:'v',45:'̣'}
,shift_alt:{8:'̤',24:'{}'}
,dk:{'\\':'ɛ[Ɛ{ɔ]Ɔ}ŋvŊVɲxƝX`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});