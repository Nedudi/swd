﻿VirtualKeyboard.addLayout({code:'CE'
,name:'Chechen Cyrillic'
,normal:'ё1234567890-ъэяшертыуиопющасдфгчйкльжзхцвбнм,.І'
,shift:{1:'!@#$%^&*()_',44:'<>'}});