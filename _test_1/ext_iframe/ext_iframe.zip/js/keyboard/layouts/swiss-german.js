﻿VirtualKeyboard.addLayout({code:'DE-CH'
,name:'Swiss German'
,normal:'§1234567890\'^$qwertzuiopü¨asdfghjklöäyxcvbnm,.-'
,shift:{0:'°+"*ç%&/()=?`£',24:'è!',35:'éà',44:';:_'}
,alt:{1:'¦@#°§¬|¢',11:'´~}',16:'€',24:'[]',36:'{'}
,shift_caps:{24:'È',35:'ÉÀ'}
,dk:{'´':'yýaáeéuúiíoóYÝAÁEÉUÚIÍOÓ ´','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãoõNÑAÃOÕ ~','¨':'yÿaäeëuüiïoöAÄEËUÜIÏOÖ ¨'}});