﻿VirtualKeyboard.addLayout({code:'FUB-CM'
,name:'Fulfulde'
,normal:'`1234567890-=\\qwertyuiopɗɓasdfghjkl;\'zxcŋbnm,./'
,shift:{0:'~!@#₦%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',19:'ƴ',24:'[]',36:'́',40:'v',45:'̣'}
,shift_alt:{24:'{}'}
,dk:{'\\':'ɗ[Ɗ{ɓ]Ɓ}yƴYƳŋVŊv`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});