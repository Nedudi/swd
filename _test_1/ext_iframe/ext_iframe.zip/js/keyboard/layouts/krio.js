﻿VirtualKeyboard.addLayout({code:'KRI-SL'
,name:'Krio'
,normal:'`1234567890-=\\qwertyuiopɛɔasdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'̱̣̌̂̇̆̑̄',24:'[]',36:'́'}
,shift_alt:{0:'̃',8:'̤',24:'{}',36:'̈'}
,dk:{'\\':'ɛ[Ɛ{ɔ]Ɔ}`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});