﻿VirtualKeyboard.addLayout({code:'EN-CA'
,name:'Canadian Multilingual Standard'
,normal:'/1234567890-=àqwertyuiop^çasdfghjkl;èzxcvbnm,.é'
,shift:{0:'\\!@#$%?&*()_+',24:'¨',35:':',44:'\'"'}
,alt:{0:'|',4:'¤',7:'{}[]',12:'¬',16:'€',24:'`~',35:'°',37:'«»',44:'<>'}
,dk:{'^':'cĉaâhĥjĵgĝsŝwŵeêuûiîyŷoôCĈAÂHĤJĴGĜSŜWŴEÊUÛIÎYŶOÔ ^','¨':'aäeëuüiïyÿoöAÄEËUÜIÏYŸOÖ ¨','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~'}});