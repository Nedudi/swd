﻿VirtualKeyboard.addLayout({code:'HY-AM'
,name:'Armenian Eastern'
,normal:'՝:ձյ՛,-.«»օռժ\'խւէրտեըիոպչջասդֆքհճկլթփզցգվբնմշղծ'
,shift:{0:'՜1',4:'349և()',13:'՞'}});