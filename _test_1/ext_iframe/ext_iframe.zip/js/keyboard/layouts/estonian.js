﻿VirtualKeyboard.addLayout({code:'ET-EE'
,name:'Estonian'
,normal:'ˇ1234567890+´\'qwertyuiopüõasdfghjklöäzxcvbnm,.-'
,shift:{0:'~!"#¤%&/()=?`*',44:';:_'}
,alt:{2:'@£$€',7:'{[]}\\',13:'½',16:'€',25:'§',27:'š',36:'^ž'}
,shift_alt:{36:'^'}
,dk:{'´':'nńcćzźsśeéoóNŃCĆZŹSŚEÉOÓ ´','`':'aàeèuùoòAÀEÈUÙOÒ `','^':'aâgĝeêuûiîAÂGĜEÊUÛIÎ ^','ˇ':'cčzžsšCČZŽSŠ ˇ','~':'oõOÕ ~'}});