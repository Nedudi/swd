﻿VirtualKeyboard.addLayout({code:'UK-UA'
,name:'Ukrainian Phonetic'
,normal:'„1234567890-єючшертиуіопяїасдфґгйклжщзхцвбнм,.ь'
,shift:{0:'“!:№;%V’?()—',44:'«»'}
,alt:{0:'`',12:'=\\',24:'[]',35:';\'',46:'/'}
,shift_alt:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,caps:{0:'“'}
,shift_caps:{0:'„'}});