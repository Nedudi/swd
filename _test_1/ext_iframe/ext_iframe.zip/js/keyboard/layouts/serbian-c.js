﻿VirtualKeyboard.addLayout({code:'SR-SP'
,name:'Serbian (Cyrillic)'
,normal:'`1234567890\'+жљњертзуиопшђасдфгхјклчћѕџцвбнм,.-'
,shift:{0:'~!"#$%&/()=?*',44:';:_'}
,alt:{16:'€',44:'<>'}
,dk:{'\'':'гѓкќГЃКЌ \''}});