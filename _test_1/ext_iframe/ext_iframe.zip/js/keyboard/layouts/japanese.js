﻿VirtualKeyboard.addLayout({code:'JA-JP'
,name:'Japanese'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,'cbk':VirtualKeyboard.Langs.JP.processChar});