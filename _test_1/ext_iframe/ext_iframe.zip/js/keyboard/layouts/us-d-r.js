﻿VirtualKeyboard.addLayout({code:'EN-US'
,name:'United States-Dvorak right'
,normal:'`1234jlmfp/[]\\56q.orsuyb;=78zaehtdck-90x,inwvg\''
,shift:{0:'~!@#$',10:'?{}|%^',17:'>',24:':+&*',36:'_()',40:'<',46:'"'}});