﻿VirtualKeyboard.addLayout({code:'DE'
,name:'German'
,normal:'^1234567890ß´#qwertzuiopü+asdfghjklöäyxcvbnm,.-'
,shift:{0:'°!"§$%&/()=?`\'',25:'*',44:';:_'}
,alt:{2:'²³',7:'{[]}\\',14:'@',16:'€',25:'~',43:'µ'}
,caps:{1:'!"§$%&/()=?',13:'\'',25:'*',44:';:'}
,shift_caps:{1:'1234567890ß',13:'#',25:'+',44:',.'}
,dk:{'´':'yýaáeéuúiíoóYÝAÁEÉUÚIÍOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});