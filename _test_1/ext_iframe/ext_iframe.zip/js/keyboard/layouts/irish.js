﻿VirtualKeyboard.addLayout({code:'EN-IE'
,name:'Irish'
,normal:'`1234567890-=#qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'¬!"£$%^&*()_+~',24:'{}',35:':@',44:'<>?'}
,alt:{0:'¦',4:'€',16:'é',20:'úíó',26:'á',36:'´'}
,shift_alt:{36:'`'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});