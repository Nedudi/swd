﻿VirtualKeyboard.addLayout({code:'EN-GB'
,name:'UK Qwerty-Maltron'
,normal:'`1234567890-=#qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'¬!"£$%^&*()_+~',24:'{}',35:':@',44:'<>?'}
,alt:{0:'¦',2:'¨',4:'€',6:'^',13:'~',15:'ẃé',19:'ýúíó',26:'á',36:'´',39:'ç'}
,shift_alt:{36:'`'}
,caps:{13:'r',15:'pycb[]vmuzl',27:'nisf\'#dtho.jg;e\\/wkx'}
,shift_caps:{19:'{}',31:'@~',37:'>',40:':',42:'|?'}
,dk:{'¨':'aäwẅeëuüiïyÿoöAÄWẄEËUÜIÏYŸOÖ ¨','^':'aâwŵeêuûiîyŷoôAÂWŴEÊUÛIÎYŶOÔ ^','´':'aáwẃeéuúiíyýoóAÁWẂEÉUÚIÍYÝOÓ ´','`':'aàwẁeèuùiìyỳoòAÀWẀEÈUÙIÌYỲOÒ `','~':'nñaãoõNÑAÃOÕ ~'}});