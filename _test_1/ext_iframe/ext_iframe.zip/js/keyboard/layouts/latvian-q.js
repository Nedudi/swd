﻿VirtualKeyboard.addLayout({code:'LV'
,name:'Latvian (QWERTY)'
,normal:'`1234567890-=°qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,alt:{0:'­ «»€',6:'’',11:'–',16:'ēŗ',20:'ūīõ',26:'āš',30:'ģ',33:'ķļ',36:'´ž',39:'č',42:'ņ'}
,shift_alt:{4:'§°',7:'±×',11:'—',36:'¨'}
,dk:{'´':'nńcćzźsśeéoóNŃCĆZŹSŚEÉOÓ ´','¨':'aäuüoöAÄUÜOÖ ¨','~':'oõOÕ ~','°':'zżaågġeėZŻAÅEĖ °'}});