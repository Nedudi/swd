﻿VirtualKeyboard.addLayout({code:'SV-SE'
,name:'Swedish Dvorak A1'
,normal:'§1234567890+´\'åäöpyfgcrl,¨aoeuidhtns-.qjkxbmwvz'
,shift:{0:'½!"#¤%&/()=?`*',24:';^',36:'_:'}
,alt:{2:'@£$€',7:'{[]}\\',14:'[]',25:'~\\~{}'}});