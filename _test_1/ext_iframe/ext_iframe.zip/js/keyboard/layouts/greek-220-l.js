﻿VirtualKeyboard.addLayout({code:'EL-GR'
,name:'Greek (220) Latin'
,normal:'\\1234567890\']#qwertyuiop+}asdfghjkl΄¨zxcvbnm,.-'
,shift:{0:'|!"#$%&/()=?[@',24:'*{',35:'¨΅',44:';:_'}
,alt:{2:'²³£§¶',8:'¤¦°±½¬',16:'€',24:'«»',35:'΅΅'}
,dk:{'΄':' ΄','¨':' ¨','΅':' ΅'}});