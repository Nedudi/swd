﻿VirtualKeyboard.addLayout({code:'IT'
,name:'Italian (142)'
,normal:'\\1234567890\'ìùqwertyuiopè+asdfghjklòàzxcvbnm,.-'
,shift:{0:'|!"£$%&/()=?^§',24:'é*',35:'ç°',44:';:_'}
,alt:{3:'#',5:'€',7:'{[]}',13:'`@',16:'€',25:'~'}});