﻿VirtualKeyboard.addLayout({code:'ES-MX'
,name:'Latin American'
,normal:'|1234567890\'¿}qwertyuiop´+asdfghjklñ{zxcvbnm,.-'
,shift:{0:'°!"#$%&/()=?¡]',24:'¨*',36:'[',44:';:_'}
,alt:{0:'¬',11:'\\',13:'`@',25:'~',36:'^'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});