﻿VirtualKeyboard.addLayout({code:'SK'
,name:'Slovak (QWERTY)'
,normal:';+ľščťžýáíé=´ňqwertyuiopúäasdfghjklô§zxcvbnm,.-'
,shift:{0:'°1234567890%ˇ)',24:'/(',35:'"!',44:'?:_'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|€',23:'\'÷×',27:'đĐ[]',33:'łŁ$ß>#&@{}',44:'<>*'}
,dk:{'ˇ':'nňcčzždďsšlľeěrřtťNŇCČZŽDĎSŠLĽEĚRŘTŤ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','˙':'zżZŻ ˙','´':'nńcćzźaásślĺeérŕuúiíyýoóNŃCĆZŹAÁSŚLĹEÉRŔUÚIÍYÝOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäeëuüoöAÄEËUÜOÖ ¨','¸':'cçsştţCÇSŞTŢ ¸'}});