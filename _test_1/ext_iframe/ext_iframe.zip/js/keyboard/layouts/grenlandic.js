﻿VirtualKeyboard.addLayout({code:'KL-GL'
,name:'Grenland'
,normal:'½1234567890+´\'qwertyuiopå¨asdfghjklæøzxcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'|',16:'€',23:'þ',25:'~',27:'ßð',33:'ĸ',43:'µ'}
,dk:{'´':'nńcćzźaáæǽøǿsślĺwẃeérŕåǻuúiíyýoóNŃCĆZŹAÁÆǼØǾSŚLĹWẂEÉRŔÅǺUÚIÍYÝOÓ ´','`':'aàwẁeèuùiìyỳoòAÀWẀEÈUÙIÌYỲOÒ `','¨':'aäwẅeëuüiïyÿoöAÄWẄEËUÜIÏYŸOÖ ¨','^':'cĉaâhĥjĵgĝsŝwŵeêuûiîyŷoôCĈAÂHĤJĴGĜSŜWŴEÊUÛIÎYŶOÔ ^','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~'}});