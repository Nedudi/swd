﻿VirtualKeyboard.addLayout({code:'PT'
,name:'Portuguese'
,normal:'\\1234567890\'«~qwertyuiop+´asdfghjklçºzxcvbnm,.-'
,shift:{0:'|!"#$%&/()=?»^',24:'*`',36:'ª',44:';:_'}
,alt:{2:'@£§€',7:'{[]}',16:'€',24:'¨]'}
,dk:{'¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãoõNÑAÃOÕ ~','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});