﻿VirtualKeyboard.addLayout({code:'EN-GB'
,name:'United Kingdom-Dvorak'
,normal:'`1234567890-=#/,.pyfgcrl[]aoeuidhtns\';qjkxbmwvz'
,shift:{0:'¬!"£$%^&*()_+~?<>',24:'{}',36:'@:'}
,alt:{0:'¦',4:'€'}});