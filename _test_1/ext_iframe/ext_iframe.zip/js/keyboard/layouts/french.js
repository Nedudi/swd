﻿VirtualKeyboard.addLayout({code:'FR'
,name:'French'
,normal:'²&é"\'(-è_çà)=*azertyuiop^$qsdfghjklmùwxcvbn,;:!'
,shift:{1:'1234567890°+µ',24:'¨£',36:'%',43:'?./§'}
,alt:{2:'~#{[|`\\^@]}',16:'€',25:'¤'}
,caps:{1:'1234567890°+µ',24:'¨£',36:'%',43:'?./§'}
,shift_caps:{1:'&é"\'(-è_çà)=*',24:'^$',36:'ù',43:',;:!'}
,dk:{'~':'nñoõaãNÑOÕAÃ ~','`':'eèuùiìoòaàEÈUÙIÌOÒAÀ `','^':'eêuûiîoôaâEÊUÛIÎOÔAÂ ^','¨':'eëuüiïyÿoöaäEËUÜIÏOÖAÄ ¨'}});