﻿VirtualKeyboard.addLayout({code:'BS-BA'
,name:'Bosnian'
,normal:'¸1234567890\'+žqwertzuiopšđasdfghjklčćyxcvbnm,.-'
,shift:{0:'¨!"#$%&/()=?*',44:';:_'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|€',24:'÷×',29:'[]',33:'łŁ',36:'ß',40:'@{}§<>'}
,dk:{'ˇ':'nňcčdďsšlľeěrřtťzžNŇCČDĎSŠLĽEĚRŘTŤZŽ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','˙':'zżZŻ ˙','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäeëuüoöAÄEËUÜOÖ ¨','¸':'cçsşCÇSŞ ¸'}});