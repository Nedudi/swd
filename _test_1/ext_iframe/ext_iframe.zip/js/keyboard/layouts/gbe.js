﻿VirtualKeyboard.addLayout({code:'GBS-BJ'
,name:'Gbe'
,normal:'`1234567890-=\\ŋwertyuiopɛɔasdfghƒkl;\'zxɖvbnm,./'
,shift:{0:'~!@#₦%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',14:'q',24:'[]',30:'ɣ',32:'j',36:'́',39:'cʋ',45:'̣'}
,shift_alt:{24:'{}'}
,dk:{'\\':'ɛ[Ɛ{ɔ]Ɔ}gɣGƔvʋVƲƒjƑJɖcƉCŋqŊQ\\\\`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱'}});