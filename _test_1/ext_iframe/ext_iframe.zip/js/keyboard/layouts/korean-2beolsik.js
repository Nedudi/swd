﻿VirtualKeyboard.addLayout({code:'KO-KR'
,name:'2 Beolsik'
,normal:'~1234567890-=\\ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔ[]ㅁㄴㅇㄹㅎㅗㅓㅏㅣ;\'ㅋㅌㅊㅍㅠㅜㅡ,./'
,shift:{0:'`!@#$%^&*()_+|ㅃㅉㄲㄲㅆ',22:'ㅒㅖ{}',35:':"',44:'<>?'}
,'cbk':VirtualKeyboard.Langs.KR.charProcessor});