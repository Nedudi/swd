﻿VirtualKeyboard.addLayout({code:'LT'
,name:'Lithuanian'
,normal:'`ąčęėįšųū90-ž\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~',9:'()_',13:'|',24:'{}',35:':"',44:'<>?'}
,alt:{1:'12345678',12:'=',16:'€'}
,shift_alt:{1:'!@#$%^&*',12:'+'}});