﻿VirtualKeyboard.addLayout({code:'ES'
,name:'Spanish'
,normal:'º1234567890\'¡çqwertyuiop`+asdfghjklñ´zxcvbnm,.-'
,shift:{0:'ª!"·$%&/()=?¿',24:'^*',36:'¨',44:';:_'}
,alt:{0:'\\|@#~€¬',13:'}',16:'€',24:'[]',36:'{'}
,dk:{'~':'nñaãoõNÑAÃOÕ ~','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨'}});