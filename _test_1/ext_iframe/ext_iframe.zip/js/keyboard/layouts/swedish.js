﻿VirtualKeyboard.addLayout({code:'SV-SE'
,name:'Swedish'
,normal:'§1234567890+´\'qwertyuiopå¨asdfghjklöäzxcvbnm,.-'
,shift:{0:'½!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}\\',16:'€',25:'~',43:'µ'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','~':'nñaãoõNÑAÃOÕ ~'}});