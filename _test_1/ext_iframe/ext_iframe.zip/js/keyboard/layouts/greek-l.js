﻿VirtualKeyboard.addLayout({code:'EL-GR'
,name:'Greek Latin'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,alt:{1:'¡²³¤€¼½¾‘’¥×¬äåé®þüúíóö«»áßð',34:'ø¶´æ',39:'©',42:'ñµç',46:'¿'}
,shift_alt:{1:'¹',4:'£',12:'÷¦',27:'§',35:'°¨',39:'¢'}
,dk:{'^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','´':'cçaáeéuúiíyýoóCÇAÁEÉUÚIÍYÝOÓ ´','¨':'aäeëuüiïyÿoöAÄEËUÜIÏYOÖ ¨','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãoõNÑAÃOÕ ~'}});