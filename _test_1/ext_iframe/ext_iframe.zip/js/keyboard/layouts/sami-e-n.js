﻿VirtualKeyboard.addLayout({code:'SE-NO'
,name:'Sami Extended Norway'
,normal:'|1234567890+\\đášertŧuiopåŋasdfghjkløæzčcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'´\'qw€',19:'y',21:'ïõ',24:'¨~â',30:'ǧǥ',33:'ǩ',35:'öäʒx',43:'µ<>'}
,shift_alt:{13:'*',24:'^ˇ'}
,dk:{'`':'aàeèuùiìoòAÀEÈUÙIÌOÒwẁyỳWẀYỲ `','´':'nńcćzźaáøǿæǽsślĺeérŕåǻuúiíoóNŃCĆZŹAÁØǾÆǼSŚLĹEÉRŔÅǺUÚIÍOÓwẃyýWẂYÝ ´','¨':'aäeëuüiïoöAÄEËUÜIÏOÖwẅyÿWẄYŸ ¨','^':'cĉaâhĥjĵgĝsŝeêuûiîoôCĈAÂHĤJĴGĜSŜEÊUÛIÎOÔwŵyŷWŴYŶ ^','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~','ˇ':'nňcčzžhȟgǧdďsšlľkǩeěrřtťNŇCČZŽHȞGǦDĎSŠLĽKǨEĚRŘTŤʒǯƷǮ ˇ'}});