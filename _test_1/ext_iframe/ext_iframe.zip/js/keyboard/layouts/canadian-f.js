﻿VirtualKeyboard.addLayout({code:'EN-CA'
,name:'Canadian French'
,normal:'#1234567890-=<qwertyuiop^¸asdfghjkl;`zxcvbnm,.é'
,shift:{0:'|!"/$%?&*()_+>',24:'^¨',35:':`',44:'\''}
,alt:{0:'\\±@£¢¤¬¦²³¼½¾}',22:'§¶[]',35:'~{',43:'µ¯­´'}
,dk:{'^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','¸':'cçCÇ ¸','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´'}});