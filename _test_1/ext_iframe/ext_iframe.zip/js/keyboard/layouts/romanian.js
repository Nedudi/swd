﻿VirtualKeyboard.addLayout({code:'RO'
,name:'Romanian'
,normal:']1234567890+\'âqwertzuiopăîasdfghjklşţyxcvbnm,.-'
,shift:{0:'[!"#¤%&/()=?*',44:';:_'}
,alt:{1:'~ˇ^˘°˛`·´˝¨¸',14:'\\|',24:'÷×',27:'đĐ',33:'łŁ$ß',40:'@{}§<>'}});