﻿VirtualKeyboard.addLayout({code:'PL'
,name:'Polish (214)'
,normal:'˛1234567890+\'óqwertzuiopżśasdfghjklłąyxcvbnm,.-'
,shift:{0:'·!"#¤%&/()=?*ź',24:'ńć',36:'ę',44:';:_'}
,alt:{1:'~ˇ^˘°˛`·´˝¨¸',14:'\\¦',20:'€',24:'÷×',27:'đĐ',35:'$ß',40:'@{}§<>'}
,dk:{'ˇ':'nňcčdďsšeěrřtťzžNŇCČDĎSŠEĚRŘTŤZŽ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','·':'zżZŻ ·','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäeëuüoöAÄEËUÜOÖ ¨','¸':'cçsştţCÇSŞTŢ ¸'}});