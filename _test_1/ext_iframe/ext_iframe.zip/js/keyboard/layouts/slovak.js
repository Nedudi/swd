﻿VirtualKeyboard.addLayout({code:'SK'
,name:'Slovak'
,normal:';+ľščťžýáíé=´ňqwertzuiopúäasdfghjklô§yxcvbnm,.-'
,shift:{0:'°1234567890%ˇ)',24:'/(',35:'"!',44:'?:_'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|€',23:'\'÷×',27:'đĐ[]',33:'łŁ$ß>#&@{}',44:'<>*'}
,dk:{'ˇ':'nňcčdďsšlľeěrřtťzžNŇCČDĎSŠLĽEĚRŘTŤZŽ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','˙':'zżZŻ ·','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäuüoöAÄUÜOÖ ¨','¸':'cçsştţCÇSŞTŢ ¸'}});