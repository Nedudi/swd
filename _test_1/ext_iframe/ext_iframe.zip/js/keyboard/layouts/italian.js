﻿VirtualKeyboard.addLayout({code:'IT'
,name:'Italian'
,normal:'\\1234567890\'ìùqwertyuiopè+asdfghjklòàzxcvbnm,.-'
,shift:{0:'|!"£$%&/()=?^§',24:'é*',35:'ç°',44:';:_'}
,alt:{5:'€',16:'€',24:'[]',35:'@#'}
,shift_alt:{24:'{}'}});