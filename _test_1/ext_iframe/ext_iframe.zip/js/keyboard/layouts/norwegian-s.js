﻿VirtualKeyboard.addLayout({code:'SE-NO'
,name:'Norwegian with Sami'
,normal:'|1234567890+\\\'qwertyuiopå¨asdfghjkløæzxcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'´',14:'â',16:'€',18:'ŧ',21:'ïõ',25:'~ášđǥǧȟ',33:'ǩ',35:'öäž',39:'čǯʒŋµ'}
,shift_alt:{31:'Ȟ'}
,dk:{'`':'aàwẁeèuùiìyỳoòAÀWẀEÈUÙIÌYỲOÒ `','´':'nńcćzźaáøǿæǽsślĺwẃeérŕåǻuúiíyýoóNŃCĆZŹAÁØǾÆǼSŚLĹWẂEÉRŔÅǺUÚIÍYÝOÓ ´','¨':'aäwẅeëuüiïyÿoöAÄWẄEËUÜIÏYŸOÖ ¨','^':'cĉaâhĥjĵgĝsŝwŵeêuûiîyŷoôCĈAÂHĤJĴGĜSŜWŴEÊUÛIÎYŶOÔ ^','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~'}});