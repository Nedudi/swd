﻿VirtualKeyboard.addLayout({code:'PT-BR'
,name:'Portuguese (Brazilian ABNT2)'
,normal:'\'1234567890-=]qwertyuiop´[asdfghjklç~zxcvbnm,.;'
,shift:{0:'"!@#$%¨&*()_+}',24:'`{',36:'^',44:'<>:'}
,alt:{1:'¹²³£¢¬',12:'§º/?°',25:'ª',39:'₢'}
,dk:{'¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãoõNÑAÃOÕ ~','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});