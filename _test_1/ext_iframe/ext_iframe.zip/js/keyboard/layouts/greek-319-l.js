﻿VirtualKeyboard.addLayout({code:'EL-GR'
,name:'Greek (319) Latin'
,normal:'\\1234567890\'+`qwertyuiop[]asdfghjkl´^zxcvbnm,.-'
,shift:{0:'|!"#$%&/()=?*@',24:'{}',35:'¨~',44:';:_'}
,alt:{16:'€'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','~':'nñaãoõNÑAÃOÕ ~','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});