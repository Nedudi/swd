﻿VirtualKeyboard.addLayout({code:'CS-CZ'
,name:'Czech Programmers'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,alt:{0:';+ěščřžýáíé=´¨',16:'€',24:'ú)',35:'ů§',44:'?:-'}
,shift_alt:{0:'°',11:'%ˇ^',24:'/(',35:'"!',44:'×÷_'}
,dk:{'´':'nńcćzźaásślĺeérŕuúiíyýoóNŃCĆZŹAÁSŚLĹEÉRŔUÚIÍYÝOÓ ´','ˇ':'nňcčzždďsšlľeěrřtťNŇCČZŽDĎSŠLĽEĚRŘTŤ ˇ','°':'aåuůAÅUŮ °','¨':'aäeëuüiïyÿoöAÄEËUÜIÏYŸOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});