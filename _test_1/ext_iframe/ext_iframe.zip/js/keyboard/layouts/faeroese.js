﻿VirtualKeyboard.addLayout({code:'FO'
,name:'Faeroese'
,normal:'½1234567890+´\'qwertyuiopåðasdfghjklæøzxcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`*',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'|',16:'€',24:'¨~',36:'^',43:'µ'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','~':'nñaãoõNÑAÃOÕ ~','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});