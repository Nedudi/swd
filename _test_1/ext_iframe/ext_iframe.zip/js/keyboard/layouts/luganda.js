﻿VirtualKeyboard.addLayout({code:'LUG-UG'
,name:'Luganda'
,normal:'`1234567890-=\\qwertyuiopŋ]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',25:'}',35:':"',44:'<>?'}
,alt:{0:'̀',4:'̱̣̌̂̇̆̑̄',24:'[',36:'́'}
,shift_alt:{0:'̃',8:'̤',24:'{',36:'̈'}
,dk:{'\\':'ŋ[Ŋ{`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});