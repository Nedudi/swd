﻿VirtualKeyboard.addLayout({code:'RUN-BI'
,name:'Kirundi'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,alt:{0:'̀',4:'̱̣̌̂̇̆̑̄',36:'́',45:'̣'}
,shift_alt:{0:'̃',8:'̤',36:'̈'}
,dk:{'\\':'`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});