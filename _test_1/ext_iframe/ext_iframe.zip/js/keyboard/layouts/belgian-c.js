﻿VirtualKeyboard.addLayout({code:'FR-BE'
,name:'Belgian (Comma)'
,normal:'²&é"\'(§è!çà)-µazertyuiop^$qsdfghjklmùwxcvbn,;:='
,shift:{0:'³1234567890°_£',24:'¨*',36:'%',43:'?./+'}
,alt:{1:'|@#{[^',9:'{}',13:'`',16:'€',24:'[]',36:'´',46:'~'}
,shift_alt:{13:'`',36:'´',46:'~'}
,caps:{1:'1234567890°_£',24:'¨*',36:'%',43:'?./+'}
,shift_caps:{1:'&é"\'(§è!çà)-µ',24:'^$',36:'ù',43:',;:='}
,dk:{'^':'eêuûiîoôaâEÊUÛIÎOÔAÂ ^','¨':'eëuüiïyÿoöaäEËUÜIÏOÖAÄ ¨','´':'eéuúiíyýoóaáEÉUÚIÍYÝOÓAÁ ´','`':'eèuùiìoòaàEÈUÙIÌOÒAÀ `','~':'nñoõaãNÑOÕAÃ ~'}});