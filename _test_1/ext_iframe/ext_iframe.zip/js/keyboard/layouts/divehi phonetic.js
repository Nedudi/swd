﻿VirtualKeyboard.addLayout({code:'DIV-MV'
,name:'Divehi Phonetic'
,normal:'`1234567890-=\\ްއެރތޔުިޮޕ][ަސދފގހޖކލ؛\'ޒ×ޗވބނމ،./'
,shift:{0:'~!@#$%^&*)(_+|ޤޢޭޜޓޠޫީޯ÷}{ާށޑﷲޣޙޛޚޅ:"ޡޘޝޥޞޏޟ><؟'}
,alt:{35:';',40:'\u200d\u200c\u200e\u200f,'}});