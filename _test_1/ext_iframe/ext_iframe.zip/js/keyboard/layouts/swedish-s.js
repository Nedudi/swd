﻿VirtualKeyboard.addLayout({code:'SE'
,name:'Swedish with Sami'
,normal:'§1234567890+´\'qwertyuiopå¨asdfghjklöäzxcvbnm,.-'
,shift:{0:'½!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}\\',14:'â',16:'€',18:'ŧ',21:'ïõ',25:'~ášđǥǧȟ',33:'ǩ',35:'øæž',39:'čǯʒŋµ'}
,shift_alt:{31:'Ȟ'}
,dk:{'´':'nńcćzźaásślĺwẃeérŕåǻuúiíyýoóNŃCĆZŹAÁSŚLĹWẂEÉRŔÅǺUÚIÍYÝOÓøǿæǽØǾÆǼ ´','`':'aàwẁeèuùiìyỳoòAÀWẀEÈUÙIÌYỲOÒ `','¨':'aäwẅeëuüiïyÿoöAÄWẄEËUÜIÏYŸOÖ ¨','^':'cĉaâhĥjĵgĝsŝwŵeêuûiîyŷoôCĈAÂHĤJĴGĜSŜWŴEÊUÛIÎYŶOÔ ^','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~'}});