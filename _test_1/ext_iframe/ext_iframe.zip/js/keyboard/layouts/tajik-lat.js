﻿VirtualKeyboard.addLayout({code:'TG'
,name:'Tajik Latin'
,normal:'`ëžčšèġîûǧ(-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~',7:'Ì',10:')_+|',24:'{}',35:':"',44:'<>?'}
,caps:{7:'Ì'}
,shift_caps:{7:'î'}});