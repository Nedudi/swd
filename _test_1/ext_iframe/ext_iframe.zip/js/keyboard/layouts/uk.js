﻿VirtualKeyboard.addLayout({code:'EN-GB'
,name:'United Kingdom'
,normal:'`1234567890-=#qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'¬!"£$%^&*()_+~',24:'{}',35:':@',44:'<>?'}
,alt:{0:'¦',4:'€',16:'é',20:'úíó',26:'á'}});