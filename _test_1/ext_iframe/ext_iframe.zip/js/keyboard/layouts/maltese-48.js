﻿VirtualKeyboard.addLayout({code:'MT'
,name:'Maltese 48-key'
,normal:'ċ1234567890-=#qwertyuiopġħasdfghjkl;\'zxcvbnm,./'
,shift:{1:'!"€$%^&*()_+~',35:':@',44:'<>?'}
,alt:{0:'`',3:'£',16:'è',20:'ùìò',24:'[]à'}
,shift_alt:{0:'¬',24:'{}'}});