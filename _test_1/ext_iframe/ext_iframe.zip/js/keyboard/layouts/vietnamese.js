﻿VirtualKeyboard.addLayout({code:'VI-VN'
,name:'Vietnamese'
,normal:'`ăâêộ̀̉̃́đ-₫\\qwertyuiopươasdfghjkl;\'zxcvbnm,./'
,shift:{0:'~',11:'_+|',35:':"',44:'<>?'}
,alt:{1:'1234567890',12:'=',24:'[]'}
,shift_alt:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}});