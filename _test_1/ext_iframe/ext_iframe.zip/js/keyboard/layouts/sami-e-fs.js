﻿VirtualKeyboard.addLayout({code:'SE'
,name:'Sami Extended Finland-Sweden'
,normal:'§1234567890+´đášertŧuiopåŋasdfghjklöäzčcvbnm,.-'
,shift:{0:'½!"#¤%&/()=?`',44:';:_'}
,alt:{0:'|',2:'@£$€',7:'{[]}\\',13:'\'qw€',19:'y',21:'ïõ',24:'¨~â',30:'ǧǥ',33:'ǩ',35:'øæʒx',43:'µ<>'}
,shift_alt:{13:'*',24:'^ˇ'}
,dk:{'´':'nńcćzźaásślĺeérŕåǻuúiíoóNŃCĆZŹAÁSŚLĹEÉRŔÅǺUÚIÍOÓøǿæǽwẃyýØǾÆǼWẂYÝ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒwẁyỳWẀYỲ `','¨':'aäeëuüiïoöAÄEËUÜIÏOÖwẅyÿWẄYŸ ¨','^':'cĉaâhĥjĵgĝsŝeêuûiîoôCĈAÂHĤJĴGĜSŜEÊUÛIÎOÔwŵyŷWŴYŶ ^','~':'nñaãuũiĩoõNÑAÃUŨIĨOÕ ~','ˇ':'nňcčzžhȟgǧdďsšlľkǩeěrřtťNŇCČZŽHȞGǦDĎSŠLĽKǨEĚRŘTŤʒǯƷǮ ˇ'}});