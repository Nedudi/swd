﻿VirtualKeyboard.addLayout({code:'KY-KG'
,name:'Kyrgyz Cyrillic'
,normal:'ё1234567890-=\\йцукенгшщзхъфывапролджэячсмитьбю.'
,shift:{1:'!"№;%:?*()_+/',46:','}
,alt:{16:'ү',19:'ң',32:'ө'}});