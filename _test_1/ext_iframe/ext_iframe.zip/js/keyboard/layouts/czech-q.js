﻿VirtualKeyboard.addLayout({code:'CS-CZ'
,name:'Czech (QWERTY)'
,normal:';+ěščřžýáíé=´¨qwertyuiopú)asdfghjklů§zxcvbnm,.-'
,shift:{0:'°1234567890%ˇ\'',24:'/(',35:'"!',44:'?:_'}
,alt:{0:'`!@#$%^&*()-=\\',16:'€',24:'[]',35:';¤',44:'<>/'}
,shift_alt:{0:'~',11:'_+|',24:'{}',35:':^',44:'×÷?'}
,dk:{'´':'nńcćzźaásślĺeérŕuúiíyýoóNŃCĆZŹAÁSŚLĹEÉRŔUÚIÍYÝOÓ ´','ˇ':'nňcčzždďsšlľeěrřtťNŇCČZŽDĎSŠLĽEĚRŘTŤ ˇ','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','°':'aåuůAÅUŮ °','¨':'aäeëuüiïyÿoöAÄEËUÜIÏYŸOÖ ¨'}});