﻿VirtualKeyboard.addLayout({code:'HE-IL'
,name:'Hebrew'
,normal:';1234567890-=\\/\'קראטוןםפ][שדגכעיחלךף,זסבהנמצתץ.'
,shift:{0:'~!@#$%^&*)(_+|QWERTYUIOP}{ASDFGHJKL:"ZXCVBNM><?'}
,alt:{4:'₪',11:'ֿ',16:'€',20:'װ',31:'ײױ'}
,caps:{14:'QWERTYUIOP',26:'ASDFGHJKL;\'ZXCVBNM,./'}
,shift_caps:{0:'ְֱֲֳִֵֶַָֹֻּׁׂ/\'קראטוןםפ[]שדגכעיחלךף',37:'זסבהנמצתץ'}});