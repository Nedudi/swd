﻿VirtualKeyboard.addLayout({code:'SQ-AL'
,name:'Albanian'
,normal:'\\1234567890-=]qwertzuiopç@asdfghjklë[yxcvbnm,./'
,shift:{0:'|!"#$%^&*()_+}',25:'\'',36:'{',44:';:?'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|',24:'÷×',27:'đĐ[]',33:'łŁ$ß',40:'@{}§<>'}
,dk:{'ˇ':'nňcčdďsšlľeěrřtťzžNŇCČDĎSŠLĽEĚRŘTŤZŽ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','˙':'zżZŻ ˙','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäeëuüoöAÄEËUÜOÖ ¨','¸':'cçsştţCÇSŞTŢ ¸'}});