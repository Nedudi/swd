﻿VirtualKeyboard.addLayout({code:'HU'
,name:'Hungarian 101-key'
,normal:'í123456789öüóűqwertyuiopőúasdfghjkléázxcvbnm,.-'
,shift:{1:'\'"+!%/=()',44:'?:_'}
,alt:{0:'0~ˇ^˘°˛`˙´˝',13:'\\\\|Ä§¤',20:'€Í',24:'÷×äđĐ[]',32:'íłŁ$ß>#&@{}<;>*'}});