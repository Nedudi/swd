﻿VirtualKeyboard.addLayout({code:'DE'
,name:'German (IBM)'
,normal:'^1234567890ß´#qwertzuiopü+asdfghjklöäyxcvbnm,.-'
,shift:{0:'°!"§$%&/()=?`\'',25:'*',44:';:_'}
,alt:{2:'²³',7:'{[]}\\',14:'@',16:'€',25:'~',43:'µ'}
,dk:{'´':'yýaáeéuúiíoóYÝAÁEÉUÚIÍOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^'}});