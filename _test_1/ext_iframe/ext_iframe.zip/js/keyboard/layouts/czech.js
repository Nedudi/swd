﻿VirtualKeyboard.addLayout({code:'CS-CZ'
,name:'Czech'
,normal:';+ěščřžýáíé=´¨qwertzuiopú)asdfghjklů§yxcvbnm,.-'
,shift:{0:'°1234567890%ˇ\'',24:'/(',35:'"!',44:'?:_'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|€',24:'÷×',27:'đĐ[]',33:'łŁ$ß',38:'#&@{}',44:'<>*'}
,dk:{'ˇ':'nňcčdďsšlľeěrřtťzžNŇCČDĎSŠLĽEĚRŘTŤZŽ ˇ','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','˘':'aăgğAĂGĞ ˘','°':'aåuůAÅUŮ °','˛':'aąeęuųiįAĄEĘUŲIĮ ˛','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','˙':'eėiızżEĖIİZŻ ·','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'yÿaäeëuüiïoöYŸAÄEËUÜIÏOÖ ¨','¸':'nņcçgģsşlļkķrŗtţNŅCÇGĢSŞLĻKĶRŖTŢ ¸'}});