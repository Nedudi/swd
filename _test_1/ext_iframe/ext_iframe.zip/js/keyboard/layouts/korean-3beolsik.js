﻿VirtualKeyboard.addLayout({code:'KO-KR'
,name:'3 Beolsik'
,normal:'~ㅎㅆㅂㅛㅠㅑㅖㅢㅜㅋ)>:ㅅㄹㅕㅐㅓㄹㄷㅁㅊㅍ(<ㅇㄴㅣㅏㅡㄴㅇㄱㅈㅂㅌㅁㄱㅔㅗㅜㅅㅎ,.ㅗ'
,shift:{0:'`ㄲㄺㅈㄿㄾ=""\'~;+\\ㅍㅌㄵㅀㄽ56789%/ㄷㄶㄼㄻㅒ01234"ㅊㅄㅋㄳ?-"\'',46:'!'}
,'cbk':VirtualKeyboard.Langs.KR.charProcessor});