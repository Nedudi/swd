﻿VirtualKeyboard.addLayout({code:'HU'
,name:'Hungarian'
,normal:'0123456789öüóűqwertzuiopőúasdfghjkléáyxcvbnm,.-'
,shift:{0:'§\'"+!%/=()',44:'?:_'}
,alt:{1:'~ˇ^˘°˛`˙´˝¨¸¤\\|Ä',20:'€Í',24:'÷×äđĐ[]',32:'íłŁ$ß>#&@{}<;>*'}
,dk:{'ˇ':'nňcčdďsšeěrřtťzžNŇCČDĎSŠEĚRŘTŤZŽ ˇ','^':'aâiîoôAÂIÎOÔ ^','˘':'aăAĂ ˘','°':'uůUŮ °','˛':'aąeęAĄEĘ ˛','˙':'zżZŻ ˙','´':'nńcćyýaásślĺeérŕuúiízźoóNŃCĆYÝAÁSŚLĹEÉRŔUÚIÍZŹOÓ ´','˝':'uűoőUŰOŐ ˝','¨':'aäeëuüoöAÄEËUÜOÖ ¨','¸':'cçsştţCÇSŞTŢ ¸'}});