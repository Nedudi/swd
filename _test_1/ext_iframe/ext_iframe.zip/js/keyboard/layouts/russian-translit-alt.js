﻿VirtualKeyboard.addLayout({code:'RU'
,name:'Russian ЯЖЕРТЫ'
,normal:'ю1234567890-=эяжертыуиопшщасдфгчйкл;\'зхцвбнм,./'
,shift:{1:'!ъЪ$%ёЁ*()_+',35:':"',44:'<>?'}});