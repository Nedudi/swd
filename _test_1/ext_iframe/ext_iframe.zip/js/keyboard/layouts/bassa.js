﻿VirtualKeyboard.addLayout({code:'BZW-NG'
,name:'Bassa'
,normal:'`1234567890-=\\ŋwertyuiopɛɔasdfghjkl;\'zɗɓvbnm,./'
,shift:{0:'~!@#₦%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',8:'̣̆',14:'q',24:'[]',36:'́',38:'xc',45:'̣'}
,shift_alt:{8:'̤',24:'{}'}
,dk:{'\\':'ɛ[Ɛ{ɔ]Ɔ}ɓcƁCɗxƊX`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\ŋqŊQ'}});