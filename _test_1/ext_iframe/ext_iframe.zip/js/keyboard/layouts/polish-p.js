﻿VirtualKeyboard.addLayout({code:'PL'
,name:'Polish (Programmers)'
,normal:'`1234567890-=\\qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#$%^&*()_+|',24:'{}',35:':"',44:'<>?'}
,alt:{16:'ę',20:'€',22:'ó',26:'ąś',34:'ł',37:'żźć',42:'ń'}
,dk:{'~':'nńcćxźzżaąsślłeęoóNŃCĆXŹZŻAĄSŚLŁEĘOÓ ~'}});