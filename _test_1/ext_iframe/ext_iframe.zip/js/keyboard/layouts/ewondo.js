﻿VirtualKeyboard.addLayout({code:'EWO-CM'
,name:'Ewondo'
,normal:'`1234567890-=\\ŋwertyuiopɛɔasdfghəkl;\'zxcvbnm,./'
,shift:{0:'~!@#₵%^&*()_+|',32:'Ǝ',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',8:'̣̆̑',14:'q',24:'[]',32:'j',36:'́'}
,shift_alt:{0:'̃',24:'{}',36:'̈'}
,dk:{'\\':'[ɛ{Ɛ]ɔ}ƆəjƎJŋqŊQ`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});