﻿VirtualKeyboard.addLayout({code:'HY-AM'
,name:'Armenian Western'
,normal:'՝:ձյ՛,-.«»օռժ\'խվէրդեըիոբչջաստֆկհճքլթփզցգւպնմշղծ'
,shift:{0:'՜1',4:'349և()',13:'՞'}});