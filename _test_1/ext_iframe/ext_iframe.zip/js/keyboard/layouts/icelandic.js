﻿VirtualKeyboard.addLayout({code:'IS'
,name:'Icelandic'
,normal:'°1234567890ö-+qwertyuiopð\'asdfghjklæ´zxcvbnm,.þ'
,shift:{0:'¨!"#$%&/()=',12:'_*',25:'?',36:'\'',44:';:'}
,alt:{0:'°',5:'€',7:'{[]}\\',13:'`@',16:'€',25:'~',36:'^',43:'µ'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','°':'aåAÅ °','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});