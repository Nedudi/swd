﻿VirtualKeyboard.addLayout({code:'WOL-SN'
,name:'Senegal Multilingual'
,normal:'`1234567890-=ëqwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{1:'!@#$%^&*()_+',24:'{}',35:':"',44:'<>?'}
,dk:{'^':'nɲcɕzʑNƝ^^','`':'bɓnŋcƈaádɗkƙeépƥtƭyƴoó``BƁNŊCƇAÁDƊKƘEÉPƤTƬYƳOÓ'}});