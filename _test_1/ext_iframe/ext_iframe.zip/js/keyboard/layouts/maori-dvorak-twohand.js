﻿VirtualKeyboard.addLayout({code:'MI-NZ'
,name:'Maori-Dvorak (Two-Handed)'
,normal:'`1234567890[]\\\',.pyfgcrl/=aoeuidhtns-;qjkxbmwvz'
,shift:{0:'~!@#$%^&*(){}|"<>',24:'?+',36:'_:'}
,dk:{'`':'aāeēuūiīoō``AĀEĒUŪIĪOŌ ~'}});