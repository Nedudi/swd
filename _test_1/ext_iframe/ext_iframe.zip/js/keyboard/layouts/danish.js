﻿VirtualKeyboard.addLayout({code:'DA-DK'
,name:'Danish'
,normal:'½1234567890+´\'qwertyuiopå¨asdfghjklæøzxcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'|',16:'€',25:'~',43:'µ'}
,dk:{'´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','~':'nñaãoõNÑAÃOÕ ~'}});