﻿VirtualKeyboard.addLayout({code:'EN-IE'
,name:'Gaelic'
,normal:'`1234567890-=#qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'`!"£$%^&*()_+~',24:'{}',35:':@',44:'<>?'}
,alt:{0:'¦',4:'€',16:'é',19:'ýúíó',26:'á',36:'\''}
,shift_alt:{0:'¬'}
,dk:{'\'':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ \'','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `'}});