﻿VirtualKeyboard.addLayout({code:'DIV-MV'
,name:'Divehi Typewriter'
,normal:'`1234567890-=]ޫޮާީޭގރމތހލ[ިުްަެވއނކފﷲޒޑސޔޅދބށޓޯ'
,shift:{0:'~!@#$%^&*)(_+}×’“/:ޤޜޣޠޙ÷{<>.،"ޥޢޘޚޡ؛ޖޕޏޗޟޛޝ\\ޞ؟'}
,alt:{29:',',36:';',40:'\u200d\u200c\u200e\u200f'}});