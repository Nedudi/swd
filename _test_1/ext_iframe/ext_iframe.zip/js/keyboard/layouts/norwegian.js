﻿VirtualKeyboard.addLayout({code:'NB-NO'
,name:'Norwegian'
,normal:'|1234567890+\\\'qwertyuiopå¨asdfghjkløæzxcvbnm,.-'
,shift:{0:'§!"#¤%&/()=?`*',25:'^',44:';:_'}
,alt:{2:'@£$€',7:'{[]}',12:'´',16:'€',25:'~',43:'µ'}
,dk:{'`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','´':'aáeéuúiíyýoóAÁEÉUÚIÍYÝOÓ ´','¨':'aäeëuüiïyÿoöAÄEËUÜIÏOÖ ¨','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','~':'nñaãoõNÑAÃOÕ ~'}});