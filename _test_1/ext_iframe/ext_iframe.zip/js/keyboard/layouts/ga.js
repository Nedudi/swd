﻿VirtualKeyboard.addLayout({code:'GAA-GH'
,name:'Ga'
,normal:'`1234567890-=\\ŋwertyuiopɛɔasdfghjkl;\'zxcvbnm,./'
,shift:{0:'~!@#₵%^&*()_+|',35:':"',44:'<>?'}
,alt:{0:'̀',4:'$',6:'̂',8:'̣̆',14:'q',24:'[]',36:'́'}
,shift_alt:{0:'̃',24:'{}',36:'̈'}
,dk:{'\\':'ɛ[Ɛ{ɔ]Ɔ}ŋqŊQ`̀\'́6̂~̃-̄9̆8̇"̈*̣:̤0̌_̱\\\\'}});