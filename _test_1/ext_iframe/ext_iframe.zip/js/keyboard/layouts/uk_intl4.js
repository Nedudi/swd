﻿VirtualKeyboard.addLayout({code:'EN-GB'
,name:'UK International'
,normal:'`1234567890-=#qwertyuiop[]asdfghjkl;\'zxcvbnm,./'
,shift:{0:'¬!"£$%^&*()_+~',24:'{}',35:':@',44:'<>?'}
,alt:{0:'¦¡²³€¤¼½¾‘’¥×',14:'åẃé®þýúíóöªºáßð',34:'ø¶´æ',39:'©',42:'ñµç',46:'¿'}
,shift_alt:{1:'¹¨',11:'±÷',24:'«»',27:'§',35:'°',39:'¢'}
,dk:{'\"':'aäeëiïoöuüwẅyÿAÄEËIÏOÖUÜWẄYŸ "','^':'aâeêiîoôuûwŵyŷAÂEÊIÎOÔUÛWŴYŶ ^','\'':'aáeéiíoóuúyýwẃcçCÇAÁEÉIÍOÓUÚYÝWẂ \'','`':'aàwẁeèuùiìyỳoòAÀWẀEÈUÙIÌYỲOÒ `','~':'nñaãoõNÑAÃOÕ ~'}});