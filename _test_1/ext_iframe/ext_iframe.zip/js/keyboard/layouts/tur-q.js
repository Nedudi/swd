﻿VirtualKeyboard.addLayout({code:'TR'
,name:'Turkish Q'
,normal:'"1234567890*-,qwertyuıopğüasdfghjklşizxcvbnmöç.'
,shift:{0:'é!\'^+%&/()=?_;',36:'İ',46:':'}
,alt:{0:'<>£#$½',7:'{[]}\\|`@',16:'€',24:'¨~æß',35:'´'}
,shift_alt:{21:'İ'}
,caps:{36:'İ'}
,shift_caps:{36:'i'}
,dk:{'^':'aâiîeêuûıîoôAÂİÎEÊUÛIÎOÔ ^','¨':'aäiïeëuüıïoöAÄİÏEËUÜIÏOÖ ¨','~':'nñaãoõNÑAÃOÕ ~','´':'aáiíeéuúıíoóAÁİÍEÉUÚIÍOÓ ´','`':'aàiìeèuùıìoòAÀİÌEÈUÙIÌOÒ `'}});