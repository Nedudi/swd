﻿VirtualKeyboard.addLayout({code:'FR-CH'
,name:'Swiss French'
,normal:'§1234567890\'^$qwertzuiopè¨asdfghjkléàyxcvbnm,.-'
,shift:{0:'°+"*ç%&/()=?`£',24:'ü!',35:'öä',44:';:_'}
,alt:{1:'¦@#°§¬|¢',11:'´~}',16:'€',24:'[]',36:'{'}
,dk:{'´':'yýaáeéuúiíoóYÝAÁEÉUÚIÍOÓ ´','^':'aâeêuûiîoôAÂEÊUÛIÎOÔ ^','`':'aàeèuùiìoòAÀEÈUÙIÌOÒ `','~':'nñaãoõNÑAÃOÕ ~','¨':'yÿaäeëuüiïoöAÄEËUÜIÏOÖ "'}});